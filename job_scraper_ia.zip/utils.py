import os
import json
import hashlib
from datetime import datetime
from typing import Any, Dict, List
import time
import random
from urllib.parse import urlparse, urlunparse

DEFAULT_UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/121.0.0.0 Safari/537.36",
]

def pick_user_agent() -> str:
    return random.choice(DEFAULT_UAS)

def normalize_url(url: str) -> str:
    """
    Normaliza URL para dedupe:
    - remove fragment
    - remove trailing slash (exceto raiz)
    """
    p = urlparse(url.strip())
    p = p._replace(fragment="")
    norm = urlunparse(p)
    if norm.endswith("/") and len(norm) > len(p.scheme) + 3:
        norm = norm[:-1]
    return norm

class DomainRateLimiter:
    """
    Rate limit por domínio com jitter.
    Ex.: min_interval=1.2 => no máximo ~0.8 req/s por domínio.
    """
    def __init__(self, min_interval: float = 1.2, jitter: float = 0.25):
        self.min_interval = float(min_interval)
        self.jitter = float(jitter)
        self._last = {}  # domain -> time

    def wait(self, url: str):
        domain = urlparse(url).netloc.lower()
        now = time.time()
        last = self._last.get(domain, 0.0)
        elapsed = now - last
        target = self.min_interval + random.uniform(0, self.jitter)
        if elapsed < target:
            time.sleep(target - elapsed)
        self._last[domain] = time.time()

def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def ensure_dirs():
    os.makedirs("output", exist_ok=True)
    os.makedirs("cache", exist_ok=True)
    os.makedirs("prompts", exist_ok=True)


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: str, data: Any):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()


def append_jsonl(path: str, obj: Dict[str, Any]):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def load_cache(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    try:
        return load_json(path)
    except Exception:
        return {}


def save_cache(path: str, cache: Dict[str, Any]):
    save_json(path, cache)


def basic_validate_result(result: Dict[str, Any]) -> bool:
    """
    Validação MVP: garante que é um dict e tem chaves mínimas.
    """
    required_keys = [
        "cargo",
        "empresa",
        "localidade",
        "tipo_trabalho",
        "senioridade",
        "requisitos_principais",
        "tecnologias",
        "salario",
        "link_candidatura",
        "data_publicacao",
        "score_0_100",
        "motivo_curto",
    ]
    if not isinstance(result, dict):
        return False
    for k in required_keys:
        if k not in result:
            return False
    return True


def to_csv_rows(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Converte para linhas simples, amigáveis pro Excel.
    """
    rows = []
    for r in results:
        rows.append({
            "cargo": r.get("cargo"),
            "empresa": r.get("empresa"),
            "localidade": r.get("localidade"),
            "tipo_trabalho": r.get("tipo_trabalho"),
            "senioridade": r.get("senioridade"),
            "salario": r.get("salario"),
            "link_candidatura": r.get("link_candidatura"),
            "score_0_100": r.get("score_0_100"),
            "motivo_curto": r.get("motivo_curto"),
            "tecnologias": ", ".join(r.get("tecnologias") or []),
            "requisitos_principais": " | ".join(r.get("requisitos_principais") or []),
            "data_publicacao": r.get("data_publicacao"),
            "url_origem": r.get("url_origem"),
        })
    return rows
