import re

SECTION_HINTS = [
    "responsabilidades", "atribuições", "atividades",
    "requisitos", "qualificações", "desejável", "diferenciais",
    "benefícios", "beneficios",
    "descrição", "descricao", "sobre a vaga", "sobre nós", "sobre a empresa",
    "local", "localidade", "modelo", "remoto", "híbrido", "presencial", "hibrido",
    "salário", "salario",
]

REMOVAL_HINTS = [
    "vaga encerrada", "oportunidade encerrada", "inscrições encerradas",
    "não está mais disponível", "nao esta mais disponivel",
    "job is no longer available", "position is no longer available",
    "404", "página não encontrada", "pagina nao encontrada",
]

def detect_status_from_text(text: str) -> str:
    t = (text or "").lower()
    for h in REMOVAL_HINTS:
        if h in t:
            return "removida"
    if len(t.strip()) < 400:
        return "duvidosa"
    return "ativa"

def clean_text(text: str) -> str:
    """Limpeza leve (sem destruir conteúdo útil)."""
    if not text:
        return ""
    t = text

    # Normaliza espaços
    t = t.replace("\r\n", "\n")
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)

    # Remove linhas muito repetitivas (heurística simples)
    lines = [ln.strip() for ln in t.split("\n")]
    filtered = []
    for ln in lines:
        if not ln:
            continue
        if len(ln) <= 2:
            continue
        filtered.append(ln)
    return "\n".join(filtered)

def extract_relevant_sections(text: str, max_chars: int = 9000) -> str:
    """
    Pega as partes mais prováveis de conter:
    descrição, responsabilidades, requisitos, benefícios, local.
    Mantém um bloco inicial curto + blocos contendo palavras-chave.
    """
    t = clean_text(text)
    if not t:
        return ""

    lines = t.split("\n")

    # sempre mantém início (título/empresa geralmente aparecem cedo)
    head = "\n".join(lines[:40])

    # seleciona linhas que contêm hints
    chosen = []
    for ln in lines:
        low = ln.lower()
        if any(h in low for h in SECTION_HINTS):
            chosen.append(ln)

    # pega também um "miolo" (caso hints falhem)
    mid = "\n".join(lines[40:220])

    out = head + "\n\n" + mid
    if chosen:
        out += "\n\n" + "\n".join(chosen[:200])

    # corta no tamanho
    out = out.strip()
    if len(out) > max_chars:
        out = out[:max_chars] + "\n\n[TRUNCADO]"
    return out
